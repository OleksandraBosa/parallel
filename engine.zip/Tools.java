/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mathpar.students.ukma17i41.bosa.parallel.engine;
//package com.mathpar.students.ukma17i41.sidko.engine;

import com.mathpar.matrix.MatrixS;
import com.mathpar.number.Element;
import com.mathpar.number.Ring;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author alla
 */
public class Tools {
    
     public static  MatrixS init(int n) {
        int[][] mat = new int[n][n];
        Random r = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = r.nextInt(10);
            }
        }
        MatrixS matS = new MatrixS(mat,Ring.ringZxyz);
        return matS;
    }
     
     
    public static  MatrixS[] concatTwoArrays(MatrixS[] mas1, MatrixS mas2[]) {
        MatrixS [] result = new MatrixS[mas1.length+mas2.length];
        int count = 0;
         
        for(int i = 0; i<mas1.length; i++) { 
            result[i] = mas1[i];
            count++;
        } 
        for(int j = 0;j<mas2.length;j++) { 
            result[count++] = mas2[j];
        }
      
        return result;
    }
    
     public static ArrayList<Integer> ArrayListCreator(int ar[]){
        ArrayList<Integer> answ=new ArrayList<Integer>();
        for (int i=0; i<ar.length; i++)
            answ.add(ar[i]);
        return answ;
    }
    
}
