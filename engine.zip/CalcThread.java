/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mathpar.students.ukma17i41.bosa.parallel.engine;
//package com.mathpar.students.ukma17i41.sidko.engine;

import com.mathpar.number.Element;
import com.mathpar.parallel.ddp.engine.AbstractFactoryOfObjects;
import com.mathpar.parallel.ddp.engine.AbstractGraphOfTask;
import com.mathpar.parallel.ddp.engine.AbstractTask;
import com.mathpar.parallel.ddp.engine.TaskQueue;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import mpi.MPI;
import mpi.MPIException;


public class CalcThread implements Runnable{
    
    Firtree firtree;
    Thread thread;
    ArrayList<DropTask> availibleDropTask;
    volatile boolean flToExit;
    volatile boolean isCalc;
    volatile boolean isNotEmptyAvailibleList;
    Object[] currentDrop;
    boolean isReadyOutputData;
    Object[] inputDrop;
    int flagOfMyState;
    int myRank;
    DropTask[] taskLevels;
 

    public boolean GetIsCalc(){
        return isCalc;
    }

    public CalcThread(ArrayList<DropTask> aDT, Firtree f) throws MPIException {
        thread=new Thread(this,"CalcThread");
        thread.setPriority(1);
        flToExit=false;
        isCalc=false;
        isNotEmptyAvailibleList = false;
        availibleDropTask=aDT;
        firtree=f;
        isReadyOutputData = false;
        flagOfMyState = 0;
        myRank=MPI.COMM_WORLD.getRank();
        thread.start();
    }
    public void DoneThread(){
        flToExit=true;
    }
    
   
    
    public synchronized  void setAmin(Object[] dropInfo){
        System.out.println("I'm in setAmin, recieved task, myrank is " + myRank);
        currentDrop = dropInfo;
        inputDrop = dropInfo;
        isCalc=true;
    }
    
    public DropTask tryLittle(int type){
    DropTask drop = null;
    switch (type){
    		case 0: drop = new Multiply();break;
    		case 1: drop = new MultiplyAdd();break;
    		/*
    		case 2: branch = new MultiplyMinus().Amin();
    		case 3: branch = new Inversion().Amin();
    		case 4: branch = new InversionAdd().Amin();
    		case 5: branch = new Cholesky().Amin();
    		case 6: branch = new MultiplyExtended().Amin();*/
    	}
    
    System.out.println("Trylittle type " + type + " created drop type "+drop.type);
    return drop;
}
    
    /**
     * 
     * @param drop
     * @return true if ready outputFunctionData
     */
    public boolean writeResultsToAmin(DropTask drop,int aminId, int dropId)
    {
    
       boolean isReadyOutputFunction  = true;
       
       for(int i=0;i<drop.arcs[dropId+1].length;i+=3)
       {
        int number = drop.arcs[dropId+1][i];
                        
             if(drop.arcs[number].length!=0){
                 isReadyOutputFunction  = false;
                 System.out.println("drop.arcs[number]!=null ");
                DropTask dependantDrop = firtree.body.get(aminId).branch.get(number);
                int from = drop.arcs[number][i+1];
                int to = drop.arcs[number][i+2];
                        
                dependantDrop.inData[to] = drop.outData[from];
                
                boolean ready = true;
             for(int j=0; j < dependantDrop.numberOfMainComponents;j++)
                {
                    if(dependantDrop.inData[j]==null)
                    {
                        ready = false;
                        break;
                    }
                }
                
                if(ready)
                {
                    if(!availibleDropTask.contains(dependantDrop))
                         availibleDropTask.add(dependantDrop);
                     
                   // System.out.println("availibledrps size add "+availibleDropTask.size());
                    dependantDrop.numberOfDaughterProc = myRank;
                }
              }
             else
             {
            
                 
                 int from = drop.arcs[number][i+1];
                 
                 System.out.println("outData[from] =  "+drop.outData[from]);
                 int to = drop.arcs[number][i+2];
                 Amin amin = firtree.body.get(aminId);
                 amin.resultForOutFunction[to] = drop.outData[from];
                 
                 System.out.println("outData[from] =  "+drop.outData[from]);
                 
                 for(int j = 0; j<amin.resultForOutFunction.length;j++)
                 {
                     if(amin.resultForOutFunction[i] == null)
                     {
                         isReadyOutputFunction = false;
                         break;
                     }
                 } }
       }
             
            for(int i=0; i<drop.outData.length;i++){
                System.out.println("outData =  "+drop.outData[i]);
            } 
            System.out.println(" isReadyOutputFunction"+ isReadyOutputFunction);
    return isReadyOutputFunction;
    
    }
     public void run(){
      
        while (!flToExit){
            if (!isCalc && !isNotEmptyAvailibleList)
            //if (!(isCalc ))
                   continue;
                try {
                    
                    ProcFunc();
                } catch (MPIException ex) {
                    Logger.getLogger(CalcThread.class.getName()).log(Level.SEVERE, null, ex);
                } 
        }
    }

    
    private void ProcFunc() throws MPIException{
     System.out.println("started proc func");
     
       System.out.println("Type is " + (int)currentDrop[0]);
     DropTask drop = tryLittle((int)currentDrop[0]);
     
     
     System.out.println("drop type " + drop.type);
     
     Element[]mas = (Element[])currentDrop[4];
       for(int i=0; i<mas.length;i++)
            drop.inData[i]= mas[i];
       
     boolean flagLittle = drop.isItLeaf();
     Amin curAmin = null;
     if(!flagLittle)
     {
         int firtreeSize = firtree.body.size();
          curAmin =  new Amin((int)currentDrop[0],(int)currentDrop[1],(int)currentDrop[2],(int)currentDrop[3],firtreeSize);
          System.out.println("Task isn't little, amin created, myrank is " + myRank);
          Element[]masInput = (Element[])currentDrop[4];
          for(int i=0; i<curAmin.inputData.length;i++)
            curAmin.inputData[i]= masInput[i];
          
          firtree.body.add(curAmin);
          Element [] resInputFunc = curAmin.branch.get(0).inputFunction(curAmin.inputData);
          System.out.println("inputFunction done, task type"+ currentDrop[0]+ "myrank is " + myRank);
       //передача даних из resInputFunc в дропи амина 
       //создание масива доступних дропов
       for(int i=0;i<drop.arcs[0].length;i+=3)
       {
           int numOfDependantDrop = drop.arcs[0][i];
           int from = drop.arcs[0][i+1];
           int to = drop.arcs[0][i+2];
           
           DropTask dependantDrop = curAmin.branch.get(numOfDependantDrop-1);
           
           dependantDrop.inData[to] = resInputFunc[from];
           
             boolean ready = true;
             for(int j=0; j < dependantDrop.numberOfMainComponents;j++)
                {
                    if(dependantDrop.inData[j]==null)
                    {
                        ready = false;
                        break;
                    }
                }
                
                if(ready)
                {
                    if(! availibleDropTask.contains(dependantDrop))
                        availibleDropTask.add(dependantDrop);
                    
                    System.out.println("availibledrps size add "+availibleDropTask.size());
                           for(int l=0; l<availibleDropTask.size();l++){
                                System.out.println("availible "+availibleDropTask.get(l).type);
                    }
                    dependantDrop.numberOfDaughterProc = myRank;
                
                }
               
       }

     }

     boolean jumpToEnd = false;
      if(flagLittle)
      {

          int curState = firtree.CheckState() == 1 && availibleDropTask.isEmpty()? 1 : 0;
          firtree.SetState(curState);
          if(curState != flagOfMyState)
          {
              flagOfMyState = curState;
              Object []state={flagOfMyState,(int)inputDrop[2],(int)inputDrop[3] };
              MPI.COMM_WORLD.send(state,1,MPI.INT,(int)inputDrop[1],2);  
              System.out.println("Sending state "+flagOfMyState+ " from " + myRank+" to "+inputDrop[1]);
          }
           
           System.out.println("Going to seq calc " + myRank+" my drop type "+drop.GetType()+" my drop "+drop.inData[0]);
           
          drop.sequentialCalc();
          System.out.println("seq calc done " + myRank);
           
          if((int)currentDrop[1] == myRank)
          {
             isReadyOutputData =  writeResultsToAmin(drop,(int)currentDrop[2],(int)currentDrop[3] );
             
              firtree.body.get((int)currentDrop[2]).branch.get((int)currentDrop[3]).state = 2;
 
          }
          else
          {
             Object []res={drop.outData,(int)currentDrop[2],(int)currentDrop[3],-1};
             MPI.COMM_WORLD.send(res,1,MPI.INT,(int)currentDrop[1],3);
             System.out.println("Sending result from " + myRank+" to "+currentDrop[1]);
             jumpToEnd = true;
          }
          
      }
      
      if(!jumpToEnd&&(int)currentDrop[2]!=-1){
      Amin amin = firtree.body.get((int)currentDrop[2]);
      
      while(isReadyOutputData)
      {  
          
          for(int k=0; k<amin.resultForOutFunction.length;k++){
              System.out.println("amin.resultForOutFunction "+amin.resultForOutFunction[k]);
          }
        amin.outputData = tryLittle(amin.type).outputFunction(amin.resultForOutFunction);
        
        if(amin.parentProc==myRank){
            isReadyOutputData = writeResultsToAmin(firtree.body.get(amin.parentAmin).branch.get(amin.dropId),amin.parentAmin, amin.dropId); 
            amin = firtree.body.get(amin.parentAmin);
        }else{
            isReadyOutputData=false;
        }
      }
      
      //?
      if(amin.parentProc!=-1 && firtree.body.indexOf(amin)!=0){
          Object []res={amin.outputData,amin.parentAmin,amin.dropId, -1};
          MPI.COMM_WORLD.send(res,1,MPI.INT,amin.parentProc,3);
          System.out.println("Sending result from " + myRank+" to "+amin.parentProc);
      }
      else
      {
          Object []res={amin.outputData,amin.parentAmin,amin.dropId, -1};
          MPI.COMM_WORLD.send(res,1,MPI.INT,myRank,3);
          System.out.println("Sending result of whole task " + myRank);
      }
      
      amin=null;
      
      }
       isNotEmptyAvailibleList = !availibleDropTask.isEmpty();
       if(isNotEmptyAvailibleList)
       {
           int numAmin = availibleDropTask.get(0).aminFirtree;
           
           System.out.println("availibledroptask  " + availibleDropTask.get(0) + "of type "+availibleDropTask.get(0).type);
           //for(int j=0; j<curAmin.branch.size();j++)
           //{
            //   System.out.println("curAmin drops "+curAmin.branch.size());
           //}
           int numDrop = firtree.body.get(numAmin).branch.indexOf(availibleDropTask.get(0));
           Object []tmp={availibleDropTask.get(0).type,myRank,numAmin,numDrop, availibleDropTask.get(0).inData};
           System.out.println("Geeting first availible task " + myRank);
           currentDrop = tmp;
            inputDrop = tmp;
           availibleDropTask.get(0).numberOfDaughterProc = myRank;
           
            System.out.println("availibledrps size add "+availibleDropTask.size());
                           for(int l=0; l<availibleDropTask.size();l++){
                                System.out.println("availible "+availibleDropTask.get(l).type);
                           }
                           
                           
           System.out.println("get first availibleDropTask "+availibleDropTask.get(0).type);
           availibleDropTask.remove(availibleDropTask.get(0));
           
           
           isCalc = true;
       }
       else
       {
           isCalc = false;
       }
       return;

       
     }
    
    
   
    
}

    

